Extract all three files to the same folder, which is under the search path of Matlab.

If you see errors like:

>> Undefined function or method 'windowMaximize' for input arguments of type 'char'

compile the c code with mex:

>> mex windowMaximize.c